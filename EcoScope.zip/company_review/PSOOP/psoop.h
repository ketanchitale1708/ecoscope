#ifndef PSOOP_H
#define PSOOP_H

#include <iostream>
#include <string>

using namespace std;

namespace PSOOPSystem
{

class Company
{
private:
    string name;
    string industry;
    string location;
    string skills;
    int jobs;
    int salary;

public:
    Company();

    void input();
    void display();
    void update();

    string getName();
};


class Node
{
public:
    Company data;
    Node* next;

    Node(Company c);
};


class CompanyLinkedList
{
private:
    Node* head;

public:
    CompanyLinkedList();

    void insert();
    void display();
    void search();
    void update();
    void remove();

    Node* linearSearch(string name);
};

}

#endif