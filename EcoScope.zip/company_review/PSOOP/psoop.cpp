#include "psoop.h"

using namespace std;

namespace PSOOPSystem
{

Company::Company()
{
    name = "";
    industry = "";
    location = "";
    skills = "";
    jobs = 0;
    salary = 0;
}


void Company::input()
{
    cout << "\nEnter Company Name: ";
    cin >> ws;
    getline(cin, name);

    cout << "Enter Industry: ";
    getline(cin, industry);

    cout << "Enter Location: ";
    getline(cin, location);

    cout << "Enter Required Skills: ";
    getline(cin, skills);

    cout << "Enter Number of Job Roles: ";
    cin >> jobs;

    cout << "Enter Average Salary: ";
    cin >> salary;
}


void Company::display()
{
    cout << "\nCompany         : " << name;
    cout << "\nIndustry        : " << industry;
    cout << "\nLocation        : " << location;
    cout << "\nRequired Skills : " << skills;
    cout << "\nJob Roles       : " << jobs;
    cout << "\nAverage Salary  : Rs. " << salary << endl;
}


void Company::update()
{
    cout << "\nEnter New Industry: ";
    cin >> ws;
    getline(cin, industry);

    cout << "Enter New Location: ";
    getline(cin, location);

    cout << "Enter New Skills: ";
    getline(cin, skills);

    cout << "Enter New Job Roles: ";
    cin >> jobs;

    cout << "Enter New Salary: ";
    cin >> salary;
}


string Company::getName()
{
    return name;
}


Node::Node(Company c)
{
    data = c;
    next = NULL;
}


CompanyLinkedList::CompanyLinkedList()
{
    head = NULL;
}


void CompanyLinkedList::insert()
{
    Company c;
    c.input();

    Node* newNode = new Node(c);

    if(head == NULL)
    {
        head = newNode;
    }
    else
    {
        Node* temp = head;

        while(temp->next != NULL)
            temp = temp->next;

        temp->next = newNode;
    }

    cout << "\nCompany added to Linked List.\n";
}


void CompanyLinkedList::display()
{
    if(head == NULL)
    {
        cout << "\nLinked List is empty.\n";
        return;
    }

    Node* temp = head;
    int i = 1;

    while(temp != NULL)
    {
        cout << "\nCompany " << i;
        temp->data.display();

        temp = temp->next;
        i++;
    }
}


Node* CompanyLinkedList::linearSearch(string name)
{
    Node* temp = head;

    while(temp != NULL)
    {
        if(temp->data.getName() == name)
            return temp;

        temp = temp->next;
    }

    return NULL;
}


void CompanyLinkedList::search()
{
    string name;

    cout << "\nEnter Company Name: ";
    cin >> ws;
    getline(cin, name);

    Node* result = linearSearch(name);

    if(result != NULL)
        result->data.display();
    else
        cout << "\nCompany not found.\n";
}


void CompanyLinkedList::update()
{
    string name;

    cout << "\nEnter Company Name: ";
    cin >> ws;
    getline(cin, name);

    Node* result = linearSearch(name);

    if(result != NULL)
        result->data.update();
    else
        cout << "\nCompany not found.\n";
}


void CompanyLinkedList::remove()
{
    string name;

    cout << "\nEnter Company Name: ";
    cin >> ws;
    getline(cin, name);

    Node* temp = head;
    Node* previous = NULL;

    while(temp != NULL)
    {
        if(temp->data.getName() == name)
        {
            if(previous == NULL)
                head = temp->next;
            else
                previous->next = temp->next;

            delete temp;

            cout << "\nCompany deleted successfully.\n";
            return;
        }

        previous = temp;
        temp = temp->next;
    }

    cout << "\nCompany not found.\n";
}

}