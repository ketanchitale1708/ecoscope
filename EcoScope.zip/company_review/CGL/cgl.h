#ifndef CGL_H
#define CGL_H

#include <GL/glut.h>
#include <string>
#include "../PL/pl.h"
#include "../COA/coa.h"

namespace CGSystem
{
void runCGL();
void init();
void display();
void keyboard(unsigned char key, int x, int y);
void special(int key, int x, int y);
void mouse(int button, int state, int x, int y);
void reshape(int w, int h);
}

#endif
