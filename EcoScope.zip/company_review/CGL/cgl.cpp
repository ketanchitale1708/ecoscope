#include "cgl.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include <vector>

using namespace std;

namespace CGSystem
{
static PLSystem::CompanyArray companyData;
static COASystem::Processor processor;

enum Screen {
    HOME, LOGIN, CREATE_ACCOUNT, STUDENT_DASH, EMPLOYER_DASH,
    COMPANIES, SEARCH, COMPANY_FORM, DETAILS, COA, ABOUT
};

static Screen screen = HOME;
static bool employerLogged = false;
static string employerUser, employerPass;
static string userInput, passInput;
static int loginField = 0;

static vector<string> form(9);
static int activeField = 0;
static bool editing = false;
static string editOriginalName;

static string searchText;
static vector<int> searchResults;
static int selectedCompany = -1;
static string statusText;
static int statusTicks = 0;

static string coaA, coaB, coaResult;
static int coaField = 0;

static int winW = 1200, winH = 760;

struct Rect { float x1,y1,x2,y2; };

static bool hit(const Rect& r, float x, float y)
{
    return x >= r.x1 && x <= r.x2 && y >= r.y1 && y <= r.y2;
}

static void color(float r,float g,float b,float a=1.0f) { glColor4f(r,g,b,a); }

static void text(float x, float y, const string& s, void* font=GLUT_BITMAP_HELVETICA_18)
{
    glRasterPos2f(x,y);
    for(unsigned char c : s) glutBitmapCharacter(font,c);
}

static float textWidth(const string& s, void* font=GLUT_BITMAP_HELVETICA_18)
{
    float w=0;
    for(unsigned char c : s) w += glutBitmapWidth(font,c);
    return w;
}

// glutBitmapWidth() returns pixel widths, but our scene is drawn in a 0..20 x 0..10
// ortho unit space, so pixel measurements must be converted to units using the
// current window width before they can be used to center text.
static float pxToUnitsX(float px){ return px * (20.0f/(float)winW); }

static void centered(float y,const string& s,void* font=GLUT_BITMAP_HELVETICA_18)
{
    float w = pxToUnitsX(textWidth(s,font));
    text((20.0f-w)/2.0f,y,s,font);
}

// Centers text horizontally inside [x1,x2] rather than across the whole screen —
// this is what button labels should use so they land inside their own button.
static void centeredIn(float x1,float x2,float y,const string& s,void* font=GLUT_BITMAP_HELVETICA_18)
{
    float w = pxToUnitsX(textWidth(s,font));
    text(x1+((x2-x1)-w)/2.0f,y,s,font);
}

static void roundedRect(float x1,float y1,float x2,float y2,float r)
{
    float rw=(x2-x1)*0.5f, rh=(y2-y1)*0.5f;
    if(r>rw) r=rw;
    if(r>rh) r=rh;
    const int segs=12;
    const float HALF_PI=1.5707963f;
    glBegin(GL_POLYGON);
    // bottom-right corner, center (x2-r,y1+r), sweep -90deg -> 0deg
    for(int i=0;i<=segs;i++){ float a=-HALF_PI + i*(HALF_PI/segs);
        glVertex2f(x2-r+r*cos(a), y1+r+r*sin(a)); }
    // top-right corner, center (x2-r,y2-r), sweep 0deg -> 90deg
    for(int i=0;i<=segs;i++){ float a=0.0f + i*(HALF_PI/segs);
        glVertex2f(x2-r+r*cos(a), y2-r+r*sin(a)); }
    // top-left corner, center (x1+r,y2-r), sweep 90deg -> 180deg
    for(int i=0;i<=segs;i++){ float a=HALF_PI + i*(HALF_PI/segs);
        glVertex2f(x1+r+r*cos(a), y2-r+r*sin(a)); }
    // bottom-left corner, center (x1+r,y1+r), sweep 180deg -> 270deg
    for(int i=0;i<=segs;i++){ float a=2*HALF_PI + i*(HALF_PI/segs);
        glVertex2f(x1+r+r*cos(a), y1+r+r*sin(a)); }
    glEnd();
}

static void panel(float x1,float y1,float x2,float y2)
{
    color(0.075f,0.125f,0.098f); roundedRect(x1,y1,x2,y2,0.35f);
    color(0.169f,0.239f,0.188f);
    glLineWidth(1.0f); glBegin(GL_LINE_LOOP);
    glVertex2f(x1,y1); glVertex2f(x2,y1); glVertex2f(x2,y2); glVertex2f(x1,y2); glEnd();
}

static void button(float x1,float y1,float x2,float y2,const string& label,bool primary=false,bool danger=false)
{
    if(danger)      color(0.769f,0.478f,0.361f);       // clay fill
    else if(primary) color(0.510f,0.725f,0.608f);      // sage fill
    else            color(0.094f,0.165f,0.125f);       // quiet panel fill
    roundedRect(x1,y1,x2,y2,0.22f);
    if(!primary && !danger){
        color(0.169f,0.239f,0.188f);
        glLineWidth(1.0f); glBegin(GL_LINE_LOOP);
        glVertex2f(x1,y1); glVertex2f(x2,y1); glVertex2f(x2,y2); glVertex2f(x1,y2); glEnd();
    }
    if(primary || danger) color(0.051f,0.090f,0.071f); // dark ink text on filled buttons
    else                  color(0.933f,0.949f,0.933f); // light text on panel
    centeredIn(x1,x2,(y1+y2)/2-0.08f,label);
}


static string trunc(const string& s,size_t n);

static void line(float x1,float y1,float x2,float y2,float width=1.0f)
{
    glLineWidth(width);
    glBegin(GL_LINES);
    glVertex2f(x1,y1); glVertex2f(x2,y2);
    glEnd();
}

static void circle(float cx,float cy,float radius,int segments=40)
{
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx,cy);
    for(int i=0;i<=segments;i++){
        float a=6.2831853f*i/segments;
        glVertex2f(cx+cos(a)*radius,cy+sin(a)*radius);
    }
    glEnd();
}

static void progressBar(float x,float y,float w,float h,float value)
{
    value=max(0.0f,min(100.0f,value));
    color(0.075f,0.125f,0.098f);
    roundedRect(x,y,x+w,y+h,0.08f);
    if(value>0){
        color(0.510f,0.725f,0.608f);
        roundedRect(x,y,x+w*(value/100.0f),y+h,0.08f);
    }
}

static void stars(float x,float y,float rating)
{
    int full=(int)floor(rating+0.001f);
    for(int i=0;i<5;i++){
        color(i<full?0.890f:0.169f, i<full?0.635f:0.239f, i<full?0.290f:0.188f);
        text(x+i*0.28f,y,"*",GLUT_BITMAP_HELVETICA_18);
    }
}

static void statCard(float x,float y,float w,float h,const string& label,
                     const string& value,const string& accent)
{
    color(0.075f,0.125f,0.098f); roundedRect(x,y,x+w,y+h,0.18f);
    color(0.169f,0.239f,0.188f); glLineWidth(1.0f);
    glBegin(GL_LINE_LOOP);
    glVertex2f(x,y); glVertex2f(x+w,y); glVertex2f(x+w,y+h); glVertex2f(x,y+h);
    glEnd();
    color(0.510f,0.725f,0.608f); text(x+0.28f,y+h-0.42f,accent,GLUT_BITMAP_HELVETICA_12);
    color(0.933f,0.949f,0.933f); text(x+0.28f,y+0.50f,value,GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f); text(x+0.28f,y+0.18f,label,GLUT_BITMAP_HELVETICA_12);
}

static void navButton(float y,const string& icon,const string& label,bool active=false)
{
    if(active) color(0.361f,0.541f,0.447f);
    else color(0.075f,0.125f,0.098f);
    roundedRect(0.35f,y,3.25f,y+0.58f,0.12f);
    if(active) color(0.933f,0.949f,0.933f); else color(0.624f,0.702f,0.651f);
    text(0.62f,y+0.20f,icon,GLUT_BITMAP_HELVETICA_12);
    color(0.933f,0.949f,0.933f);
    text(1.02f,y+0.20f,label,GLUT_BITMAP_HELVETICA_12);
}

static void sidebar(bool employer,int active)
{
    color(0.075f,0.125f,0.098f);
    glBegin(GL_QUADS);
    glVertex2f(0,0); glVertex2f(3.6f,0); glVertex2f(3.6f,10); glVertex2f(0,10);
    glEnd();

    color(0.510f,0.725f,0.608f);
    circle(0.72f,9.18f,0.32f,32);
    color(0.051f,0.090f,0.071f);
    text(0.61f,9.10f,"E",GLUT_BITMAP_HELVETICA_18);
    color(0.933f,0.949f,0.933f);
    text(1.15f,9.08f,"ECOSCOPE",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(1.15f,8.72f,employer?"EMPLOYER MODE":"STUDENT MODE",GLUT_BITMAP_HELVETICA_10);

    navButton(7.65f,"01","Dashboard",active==0);
    if(employer) navButton(6.92f,"02","Add Company",active==1);
    navButton(6.19f,"03","Companies",active==2);
    navButton(5.46f,"04","Search",active==3);
    navButton(4.73f,"05","Analytics",active==4);
    navButton(4.00f,"06","About",active==5);

    color(0.169f,0.239f,0.188f);
    line(0.55f,2.95f,3.05f,2.95f);
    color(0.624f,0.702f,0.651f);
    text(0.55f,2.58f,"PROJECT INTEGRATION",GLUT_BITMAP_HELVETICA_10);
    color(0.624f,0.702f,0.651f);
    text(0.55f,2.20f,"PL  Array + Search",GLUT_BITMAP_HELVETICA_10);
    text(0.55f,1.88f,"PSOOP  Linked List",GLUT_BITMAP_HELVETICA_10);
    text(0.55f,1.56f,"OOPS  Accounts",GLUT_BITMAP_HELVETICA_10);
    text(0.55f,1.24f,"COA  Salary Analysis",GLUT_BITMAP_HELVETICA_10);
    text(0.55f,0.92f,"CGL  Visual Dashboard",GLUT_BITMAP_HELVETICA_10);
}

static void dashboardTop(const string& heading,const string& sub)
{
    color(0.933f,0.949f,0.933f); text(4.05f,9.12f,heading,GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f); text(4.05f,8.68f,sub,GLUT_BITMAP_HELVETICA_12);
    color(0.169f,0.239f,0.188f); line(4.05f,8.35f,19.35f,8.35f);
}

static void companyMiniCard(float x,float y,float w,float h,int idx,bool clickable=true)
{
    PLSystem::CompanyView v;
    if(!companyData.getAt(idx,v)) return;
    color(0.075f,0.125f,0.098f); roundedRect(x,y,x+w,y+h,0.16f);
    color(0.169f,0.239f,0.188f);
    glBegin(GL_LINE_LOOP);
    glVertex2f(x,y); glVertex2f(x+w,y); glVertex2f(x+w,y+h); glVertex2f(x,y+h);
    glEnd();

    color(0.510f,0.725f,0.608f);
    roundedRect(x+0.22f,y+h-0.72f,x+0.66f,y+h-0.28f,0.08f);
    color(0.051f,0.090f,0.071f);
    text(x+0.33f,y+h-0.60f,"C",GLUT_BITMAP_HELVETICA_12);

    color(0.933f,0.949f,0.933f);
    text(x+0.84f,y+h-0.48f,trunc(v.name,20),GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(x+0.25f,y+h-1.02f,trunc(v.industry,24),GLUT_BITMAP_HELVETICA_12);
    text(x+0.25f,y+h-1.36f,trunc(v.location,25),GLUT_BITMAP_HELVETICA_12);

    stars(x+0.25f,y+0.36f,v.rating);
    color(0.933f,0.949f,0.933f);
    stringstream rs; rs<<fixed<<setprecision(1)<<v.rating<<"/5";
    text(x+1.72f,y+0.38f,rs.str(),GLUT_BITMAP_HELVETICA_12);

    color(0.624f,0.702f,0.651f); text(x+3.35f,y+0.38f,"SKILL",GLUT_BITMAP_HELVETICA_10);
    progressBar(x+3.95f,y+0.31f,w-4.85f,0.16f,(float)v.skillTransparency);
    color(0.624f,0.702f,0.651f);
    text(x+w-0.72f,y+0.38f,to_string(v.skillTransparency)+"%",GLUT_BITMAP_HELVETICA_10);
}

static void operationsCard(float x,float y,float w,float h,const string& number,
                           const string& label,const string& desc,bool primary=false)
{
    if(primary) color(0.094f,0.165f,0.125f); else color(0.075f,0.125f,0.098f);
    roundedRect(x,y,x+w,y+h,0.16f);
    if(primary) color(0.510f,0.725f,0.608f); else color(0.169f,0.239f,0.188f);
    circle(x+0.42f,y+h-0.42f,0.19f,24);
    color(0.051f,0.090f,0.071f);
    text(x+0.36f,y+h-0.48f,number,GLUT_BITMAP_HELVETICA_10);
    color(0.933f,0.949f,0.933f);
    text(x+0.78f,y+h-0.50f,label,GLUT_BITMAP_HELVETICA_12);
    color(0.624f,0.702f,0.651f);
    text(x+0.28f,y+0.26f,desc,GLUT_BITMAP_HELVETICA_10);
}


static void title(const string& t,const string& sub="")
{
    color(0.510f,0.725f,0.608f); text(0.8f,9.15f,"ECOSCOPE",GLUT_BITMAP_HELVETICA_18);
    color(0.933f,0.949f,0.933f); text(0.8f,8.35f,t,GLUT_BITMAP_HELVETICA_18);
    if(!sub.empty()){ color(0.624f,0.702f,0.651f); text(0.8f,7.82f,sub,GLUT_BITMAP_HELVETICA_12); }
}

static void footer()
{
    color(0.624f,0.702f,0.651f);
    text(0.8f,0.45f,"ESC  Exit     B  Back     Enter  Select/Save",GLUT_BITMAP_HELVETICA_12);
    if(statusTicks>0 && !statusText.empty()){
        color(0.510f,0.725f,0.608f); text(12.0f,0.45f,statusText,GLUT_BITMAP_HELVETICA_12);
    }
}

static void setStatus(const string& s)
{
    statusText=s; statusTicks=360; glutPostRedisplay();
}

static string maskPassword(const string& p)
{
    return string(p.size(),'*');
}

static void clearScreen()
{
    color(0.051f,0.090f,0.071f); glClear(GL_COLOR_BUFFER_BIT);
}

static void home()
{
    clearScreen();

    // Background decorative primitives.
    color(0.051f,0.090f,0.071f);
    glBegin(GL_QUADS);
    glVertex2f(0,0); glVertex2f(20,0); glVertex2f(20,10); glVertex2f(0,10);
    glEnd();

    glPushMatrix();
    glTranslatef(15.8f,7.4f,0);
    glRotatef(18.0f,0,0,1);
    color(0.094f,0.165f,0.125f);
    glBegin(GL_TRIANGLES);
    glVertex2f(0,1.8f); glVertex2f(-1.8f,-1.0f); glVertex2f(1.8f,-1.0f);
    glEnd();
    glPopMatrix();

    color(0.510f,0.725f,0.608f);
    text(1.05f,8.95f,"ECOSCOPE",GLUT_BITMAP_HELVETICA_18);
    color(0.933f,0.949f,0.933f);
    text(1.05f,7.65f,"COMPANY REVIEW",GLUT_BITMAP_HELVETICA_18);
    text(1.05f,7.08f,"& SKILL TRANSPARENCY",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(1.05f,6.45f,"Review companies. Search skills. Compare salary data.",GLUT_BITMAP_HELVETICA_12);

    panel(1.05f,3.15f,8.15f,5.75f);
    color(0.933f,0.949f,0.933f);
    text(1.45f,5.22f,"GET STARTED",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(1.45f,4.72f,"Choose how you want to use the system.",GLUT_BITMAP_HELVETICA_12);
    button(1.45f,3.95f,4.35f,4.48f,"STUDENT LOGIN",true);
    button(4.60f,3.95f,7.75f,4.48f,"EMPLOYER LOGIN",true);
    button(1.45f,3.35f,4.35f,3.78f,"CREATE ACCOUNT");
    button(4.60f,3.35f,7.75f,3.78f,"ABOUT");

    panel(10.15f,2.05f,18.95f,6.45f);
    color(0.510f,0.725f,0.608f);
    text(10.60f,5.85f,"ONE DASHBOARD",GLUT_BITMAP_HELVETICA_18);
    color(0.933f,0.949f,0.933f);
    text(10.60f,5.28f,"Company Records",GLUT_BITMAP_HELVETICA_12);
    text(10.60f,4.75f,"Skill Transparency",GLUT_BITMAP_HELVETICA_12);
    text(10.60f,4.22f,"Reviews & Ratings",GLUT_BITMAP_HELVETICA_12);
    text(10.60f,3.69f,"Salary Analytics",GLUT_BITMAP_HELVETICA_12);
    color(0.624f,0.702f,0.651f);
    text(10.60f,2.95f,"PL + PSOOP + OOPS + COA + CGL",GLUT_BITMAP_HELVETICA_12);

    footer();
}

static void loginStoryPanel()
{
    // Logo mark.
    color(0.510f,0.725f,0.608f); circle(0.85f,9.05f,0.30f,32);
    color(0.051f,0.090f,0.071f); text(0.74f,8.97f,"E",GLUT_BITMAP_HELVETICA_18);
    color(0.933f,0.949f,0.933f); text(1.30f,9.00f,"ECOSCOPE",GLUT_BITMAP_HELVETICA_18);

    // Headline.
    color(0.933f,0.949f,0.933f); text(0.6f,7.85f,"See the company",GLUT_BITMAP_HELVETICA_18);
    color(0.510f,0.725f,0.608f); text(0.6f,7.28f,"before you sign.",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(0.6f,6.72f,"Real reviews, honest skills and salary",GLUT_BITMAP_HELVETICA_12);
    text(0.6f,6.42f,"ranges, from people who worked there.",GLUT_BITMAP_HELVETICA_12);

    // Feature list.
    const char* heads[3] = {"Verified reviews","Skill transparency","Salary insight"};
    const char* descs[3] = {"Ratings from real employees, by role.",
                             "See what each company expects, upfront.",
                             "Compare average pay across companies."};
    float y = 5.55f;
    for(int i=0;i<3;i++){
        color(0.890f,0.635f,0.290f); circle(0.72f,y+0.06f,0.055f,16);
        color(0.933f,0.949f,0.933f); text(0.95f,y,heads[i],GLUT_BITMAP_HELVETICA_12);
        color(0.624f,0.702f,0.651f); text(0.95f,y-0.32f,descs[i],GLUT_BITMAP_HELVETICA_10);
        y -= 0.92f;
    }

    color(0.169f,0.239f,0.188f); line(0.6f,2.35f,9.0f,2.35f);
    color(0.624f,0.702f,0.651f);
    text(0.6f,1.95f,"PL + PSOOP + OOPS + COA + CGL",GLUT_BITMAP_HELVETICA_10);
}

static void loginPage()
{
    clearScreen();
    loginStoryPanel();

    panel(9.8f,1.05f,19.2f,8.7f);
    color(0.933f,0.949f,0.933f); text(10.3f,7.95f,"Welcome back",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(10.3f,7.52f,employerLogged?"Log in to manage company records.":"Log in to browse companies.",
         GLUT_BITMAP_HELVETICA_12);
    color(0.890f,0.635f,0.290f);
    text(10.3f,7.14f,employerLogged?"EMPLOYER ACCOUNT":"STUDENT ACCOUNT",GLUT_BITMAP_HELVETICA_10);

    color(0.624f,0.702f,0.651f); text(10.3f,6.55f,"USERNAME",GLUT_BITMAP_HELVETICA_12);
    panel(10.3f,5.85f,18.7f,6.40f);
    color(0.933f,0.949f,0.933f); text(10.55f,6.05f,userInput);

    color(0.624f,0.702f,0.651f); text(10.3f,5.35f,"PASSWORD",GLUT_BITMAP_HELVETICA_12);
    panel(10.3f,4.65f,18.7f,5.20f);
    color(0.933f,0.949f,0.933f); text(10.55f,4.85f,maskPassword(passInput));

    button(10.3f,3.55f,18.7f,4.15f,"LOGIN",true);

    color(0.169f,0.239f,0.188f); line(10.3f,3.05f,18.7f,3.05f);
    color(0.624f,0.702f,0.651f);
    text(10.3f,2.65f,"TAB switches field  •  ENTER logs in  •  B returns",GLUT_BITMAP_HELVETICA_10);
    if(!employerLogged){
        color(0.624f,0.702f,0.651f); text(10.3f,2.30f,"Demo student login: student / 1234",GLUT_BITMAP_HELVETICA_10);
    }
    footer();
}

static void createAccountPage()
{
    clearScreen();
    loginStoryPanel();

    panel(9.8f,1.05f,19.2f,8.7f);
    color(0.933f,0.949f,0.933f); text(10.3f,7.95f,"Create employer account",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(10.3f,7.52f,"Stored in memory for this run only.",GLUT_BITMAP_HELVETICA_12);

    color(0.624f,0.702f,0.651f); text(10.3f,6.55f,"NEW USERNAME",GLUT_BITMAP_HELVETICA_12);
    panel(10.3f,5.85f,18.7f,6.40f);
    color(0.933f,0.949f,0.933f); text(10.55f,6.05f,userInput);

    color(0.624f,0.702f,0.651f); text(10.3f,5.35f,"NEW PASSWORD",GLUT_BITMAP_HELVETICA_12);
    panel(10.3f,4.65f,18.7f,5.20f);
    color(0.933f,0.949f,0.933f); text(10.55f,4.85f,maskPassword(passInput));

    button(10.3f,3.55f,18.7f,4.15f,"CREATE ACCOUNT",true);
    color(0.169f,0.239f,0.188f); line(10.3f,3.05f,18.7f,3.05f);
    color(0.624f,0.702f,0.651f);
    text(10.3f,2.65f,"TAB switches field  •  ENTER creates the account",GLUT_BITMAP_HELVETICA_10);
    footer();
}

static void dashboard(bool employer)
{
    clearScreen();
    sidebar(employer,0);
    dashboardTop(employer?"Company Management Dashboard":"Company Explorer Dashboard",
                 employer?"Manage company records, reviews and transparency data."
                         :"Discover companies, compare skills and review salary information.");

    int n=companyData.countRecords();
    float avgRating=0.0f, avgTransparency=0.0f, avgSalary=0.0f;
    int totalJobs=0;
    for(int i=0;i<n;i++){
        PLSystem::CompanyView v; companyData.getAt(i,v);
        avgRating+=v.rating; avgTransparency+=v.skillTransparency;
        avgSalary+=(float)v.salary; totalJobs+=v.jobs;
    }
    if(n>0){ avgRating/=n; avgTransparency/=n; avgSalary/=n; }

    statCard(4.05f,7.15f,3.55f,0.92f,"COMPANIES",to_string(n),"01");
    statCard(7.80f,7.15f,3.55f,0.92f,"OPEN JOB ROLES",to_string(totalJobs),"02");
    {
        stringstream ss; ss<<fixed<<setprecision(1)<<avgRating<<"/5";
        statCard(11.55f,7.15f,3.55f,0.92f,"AVG. RATING",ss.str(),"03");
    }
    statCard(15.30f,7.15f,3.55f,0.92f,"AVG. TRANSPARENCY",
             to_string((int)avgTransparency)+"%","04");

    color(0.933f,0.949f,0.933f);
    text(4.05f,6.68f,"Quick Operations",GLUT_BITMAP_HELVETICA_18);

    if(employer){
        operationsCard(4.05f,5.35f,3.55f,1.05f,"01","ADD COMPANY","Create a new company record.",true);
        operationsCard(7.80f,5.35f,3.55f,1.05f,"02","MANAGE","Browse, edit or delete records.");
        operationsCard(11.55f,5.35f,3.55f,1.05f,"03","SEARCH","Find by name, industry or skill.");
        operationsCard(15.30f,5.35f,3.55f,1.05f,"04","ANALYTICS","COA salary comparison.");
    }else{
        operationsCard(4.05f,5.35f,3.55f,1.05f,"01","BROWSE","Explore all company records.",true);
        operationsCard(7.80f,5.35f,3.55f,1.05f,"02","SEARCH","Find a company or skill.");
        operationsCard(11.55f,5.35f,3.55f,1.05f,"03","ANALYTICS","View salary comparison.");
        operationsCard(15.30f,5.35f,3.55f,1.05f,"04","ABOUT","See project integration.");
    }

    color(0.933f,0.949f,0.933f);
    text(4.05f,4.92f,"Featured Companies",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(16.05f,4.95f,"Click a card to view details",GLUT_BITMAP_HELVETICA_10);

    int shown=min(n,4);
    for(int i=0;i<shown;i++){
        float col=i%2,row=i/2;
        companyMiniCard(4.05f+col*7.65f,2.90f-row*1.68f,7.15f,1.48f,i);
    }
    if(n==0){
        panel(4.05f,2.90f,19.05f,4.55f);
        color(0.624f,0.702f,0.651f);
        text(4.45f,3.65f,employer?"No company records yet. Use ADD COMPANY to start."
                                  :"No companies are available yet.",GLUT_BITMAP_HELVETICA_12);
    }

    // Small transformed CGL accent: demonstrates 2D translation/rotation with primitives.
    glPushMatrix();
    glTranslatef(18.65f,9.03f,0);
    glRotatef((float)(glutGet(GLUT_ELAPSED_TIME)%3600)/10.0f,0,0,1);
    color(0.510f,0.725f,0.608f,0.35f);
    glBegin(GL_TRIANGLES);
    glVertex2f(0,0.18f); glVertex2f(-0.16f,-0.12f); glVertex2f(0.16f,-0.12f);
    glEnd();
    glPopMatrix();

    color(0.624f,0.702f,0.651f);
    text(4.05f,0.42f,"CGL: OpenGL primitives • 2D projection • transformations • color-based visual indicators",
         GLUT_BITMAP_HELVETICA_10);
    footer();
}

static void companiesPage(const string& heading)
{
    clearScreen();
    sidebar(employerLogged,2);
    dashboardTop(heading,"Select a company to open its complete review, salary and skill-transparency profile.");

    int n=companyData.countRecords();
    if(n==0){
        panel(4.05f,3.0f,19.0f,6.2f);
        color(0.624f,0.702f,0.651f);
        text(4.55f,4.70f,"No company records are available.",GLUT_BITMAP_HELVETICA_18);
        text(4.55f,4.20f,employerLogged?"Choose Add Company from the sidebar.":"Please check back after records are added.",
             GLUT_BITMAP_HELVETICA_12);
        footer(); return;
    }

    int shown=min(n,8);
    for(int i=0;i<shown;i++){
        float col=i%2,row=i/2;
        companyMiniCard(4.05f+col*7.65f,6.65f-row*1.55f,7.15f,1.35f,i);
    }
    if(n>8){
        color(0.624f,0.702f,0.651f);
        text(4.05f,0.95f,"Showing first 8 records. Use Search to find a specific company.",
             GLUT_BITMAP_HELVETICA_10);
    }
    footer();
}

static string trunc(const string& s,size_t n){ return s.size()>n?s.substr(0,n-3)+"...":s; }

static void searchPage()
{
    clearScreen(); title("Search Companies","Linear search from the PL array; type a name or keyword.");
    panel(1.0f,7.0f,19.0f,7.65f);
    color(0.933f,0.949f,0.933f); text(1.25f,7.22f,searchText);
    button(16.5f,6.95f,18.7f,7.65f,"SEARCH",true);

    if(searchResults.empty() && !searchText.empty()){
        color(0.624f,0.702f,0.651f); centered(5.9f,"No matching companies.",GLUT_BITMAP_HELVETICA_12);
    }
    for(size_t k=0;k<searchResults.size() && k<6;k++){
        PLSystem::CompanyView v; companyData.getAt(searchResults[k],v);
        float y=5.75f-k*0.85f;
        panel(1.0f,y-0.55f,19.0f,y+0.15f);
        color(0.933f,0.949f,0.933f); text(1.25f,y-0.15f,v.name);
        color(0.624f,0.702f,0.651f); text(6.0f,y-0.15f,v.industry);
        text(10.5f,y-0.15f,v.location);
        text(14.0f,y-0.15f,"Rating "+to_string((int)v.rating)+"/5");
        text(16.8f,y-0.15f,to_string(v.skillTransparency)+"%");
    }
    footer();
}

static void drawFormField(float x,float y,float w,const string& label,const string& val,bool active)
{
    color(0.624f,0.702f,0.651f); text(x,y+0.28f,label,GLUT_BITMAP_HELVETICA_12);
    if(active) color(0.361f,0.541f,0.447f); else color(0.075f,0.125f,0.098f);
    roundedRect(x,y-0.15f,x+w,y+0.18f,0.12f);
    color(0.933f,0.949f,0.933f); text(x+0.18f,y-0.02f,val);
}

static void companyForm()
{
    clearScreen(); title(editing?"Edit Company":"Add Company",
                          "All fields stay inside the GUI; no console input is required.");
    float left=0.9f,right=10.4f;
    drawFormField(left,7.25f,8.6f,"COMPANY NAME",form[0],activeField==0);
    drawFormField(right,7.25f,8.6f,"INDUSTRY",form[1],activeField==1);
    drawFormField(left,6.05f,8.6f,"LOCATION",form[2],activeField==2);
    drawFormField(right,6.05f,8.6f,"REQUIRED SKILLS",form[3],activeField==3);
    drawFormField(left,4.85f,8.6f,"JOB ROLES",form[4],activeField==4);
    drawFormField(right,4.85f,8.6f,"AVERAGE SALARY (RS.)",form[5],activeField==5);
    drawFormField(left,3.65f,8.6f,"RATING (0-5)",form[6],activeField==6);
    drawFormField(right,3.65f,8.6f,"SKILL TRANSPARENCY (0-100)",form[7],activeField==7);
    drawFormField(left,2.45f,18.1f,"EMPLOYEE REVIEW",form[8],activeField==8);
    button(8.0f,1.35f,12.0f,1.95f,editing?"SAVE CHANGES":"ADD COMPANY",true);
    color(0.624f,0.702f,0.651f);
    text(0.9f,1.52f,"TAB / arrows = next field • ENTER = save • ESC = cancel",GLUT_BITMAP_HELVETICA_12);
    footer();
}

static void details(int idx)
{
    clearScreen();
    PLSystem::CompanyView v;
    if(!companyData.getAt(idx,v)){ screen=COMPANIES; return; }
    title(v.name,"Company profile, employee review and skill transparency");
    panel(0.8f,2.0f,19.2f,7.2f);
    color(0.510f,0.725f,0.608f); text(1.2f,6.55f,v.industry,GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f); text(1.2f,6.05f,"Location: "+v.location);
    text(1.2f,5.35f,"Required skills: "+v.skills);
    text(1.2f,4.65f,"Open job roles: "+to_string(v.jobs));
    text(1.2f,3.95f,"Average salary: Rs. "+to_string(v.salary));
    text(10.3f,6.55f,"Rating: "+to_string(v.rating)+"/5",GLUT_BITMAP_HELVETICA_18);
    text(10.3f,5.95f,"Skill transparency: "+to_string(v.skillTransparency)+"%");
    text(10.3f,5.25f,"Review:");
    color(0.933f,0.949f,0.933f); text(10.3f,4.75f,trunc(v.review,48),GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(10.3f,4.15f,"This score describes how clearly");
    text(10.3f,3.75f,"the role's required skills are listed.");
    button(5.2f,2.35f,8.4f,2.95f,"BACK");
    if(employerLogged){
        button(8.8f,2.35f,12.0f,2.95f,"EDIT",true);
        button(12.6f,2.35f,16.0f,2.95f,"DELETE",false,true);
    }
    footer();
}

static void coaPage()
{
    clearScreen(); title("COA Analytics","64-bit salary arithmetic and comparison using the COA module.");
    drawFormField(2.0f,6.8f,7.0f,"SALARY A",coaA,coaField==0);
    drawFormField(11.0f,6.8f,7.0f,"SALARY B",coaB,coaField==1);
    button(2.0f,5.45f,6.9f,6.05f,"64-BIT ADD",true);
    button(7.9f,5.45f,12.8f,6.05f,"COMPARE");
    panel(2.0f,3.2f,18.0f,4.75f);
    color(0.624f,0.702f,0.651f); text(2.5f,4.25f,"RESULT",GLUT_BITMAP_HELVETICA_12);
    color(0.933f,0.949f,0.933f); text(2.5f,3.7f,coaResult,GLUT_BITMAP_HELVETICA_18);
    footer();
}

static void aboutPage()
{
    clearScreen();
    sidebar(employerLogged,5);
    dashboardTop("About EcoScope","How the academic subjects are integrated into one company transparency application.");

    panel(4.05f,5.35f,19.05f,7.80f);
    color(0.510f,0.725f,0.608f); text(4.45f,7.25f,"COMPANY REVIEW & SKILL TRANSPARENCY",GLUT_BITMAP_HELVETICA_18);
    color(0.624f,0.702f,0.651f);
    text(4.45f,6.72f,"A single GUI connects the project operations with the subject-wise implementations.",GLUT_BITMAP_HELVETICA_12);

    color(0.933f,0.949f,0.933f);
    text(4.45f,6.05f,"Programming Lab",GLUT_BITMAP_HELVETICA_12);
    text(9.15f,6.05f,"Company array, CRUD and linear search",GLUT_BITMAP_HELVETICA_12);
    text(4.45f,5.62f,"PSOOP",GLUT_BITMAP_HELVETICA_12);
    text(9.15f,5.62f,"Linked-list company/review data structure",GLUT_BITMAP_HELVETICA_12);
    text(4.45f,5.19f,"OOPS",GLUT_BITMAP_HELVETICA_12);
    text(9.15f,5.19f,"Account abstraction, inheritance and polymorphism",GLUT_BITMAP_HELVETICA_12);

    panel(4.05f,2.75f,19.05f,4.95f);
    color(0.933f,0.949f,0.933f);
    text(4.45f,4.45f,"Computer Organization & Architecture",GLUT_BITMAP_HELVETICA_12);
    text(4.45f,4.02f,"64-bit salary arithmetic and comparison are exposed through Analytics.",GLUT_BITMAP_HELVETICA_12);
    text(4.45f,3.48f,"Computer Graphics",GLUT_BITMAP_HELVETICA_12);
    text(4.45f,3.05f,"OpenGL primitives, 2D projection, transformations, clipping-safe cards and color",
         GLUT_BITMAP_HELVETICA_12);
    text(4.45f,2.68f,"coding are used to create the interactive dashboard interface.",
         GLUT_BITMAP_HELVETICA_12);
    footer();
}

static void render()
{
    if(statusTicks>0) --statusTicks;
    switch(screen){
        case HOME: home(); break;
        case LOGIN: loginPage(); break;
        case CREATE_ACCOUNT: createAccountPage(); break;
        case STUDENT_DASH: dashboard(false); break;
        case EMPLOYER_DASH: dashboard(true); break;
        case COMPANIES: companiesPage("Company Records"); break;
        case SEARCH: searchPage(); break;
        case COMPANY_FORM: companyForm(); break;
        case DETAILS: details(selectedCompany); break;
        case COA: coaPage(); break;
        case ABOUT: aboutPage(); break;
    }
    glutSwapBuffers();
    if(statusTicks>0) glutPostRedisplay();
}

static void resetForm()
{
    form.assign(9,"");
    activeField=0;
    editing=false;
    editOriginalName="";
}

static bool numericField(int f)
{
    return f==4 || f==5 || f==6 || f==7;
}

static void nextField()
{
    activeField=(activeField+1)%9;
}

static void saveForm()
{
    if(form[0].empty()||form[1].empty()||form[2].empty()||form[3].empty()){
        setStatus("Fill all required fields."); return;
    }
    int jobs=0,trans=0; long long salary=0; float rating=0;
    try{
        jobs=stoi(form[4]); salary=stoll(form[5]); rating=stof(form[6]); trans=stoi(form[7]);
    }catch(...){ setStatus("Use valid numbers in numeric fields."); return; }
    if(jobs<0||salary<0||rating<0||rating>5||trans<0||trans>100){
        setStatus("Check rating, salary, jobs and transparency values."); return;
    }
    bool ok;
    if(editing) ok=companyData.updateGUI(editOriginalName,form[0],form[1],form[2],form[3],
                                          jobs,salary,rating,form[8],trans);
    else ok=companyData.addGUI(form[0],form[1],form[2],form[3],
                                jobs,salary,rating,form[8],trans);
    if(!ok){ setStatus(editing?"Update failed (duplicate/not found).":"Add failed (duplicate or full array)."); return; }
    setStatus(editing?"Company updated.":"Company added.");
    screen=employerLogged?EMPLOYER_DASH:COMPANIES;
}

static void doSearch()
{
    searchResults.clear();
    string q=searchText;
    transform(q.begin(),q.end(),q.begin(),[](unsigned char c){return (char)tolower(c);});
    for(int i=0;i<companyData.countRecords();++i){
        PLSystem::CompanyView v; companyData.getAt(i,v);
        string s=v.name+" "+v.industry+" "+v.location+" "+v.skills;
        transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)tolower(c);});
        if(q.empty() || s.find(q)!=string::npos) searchResults.push_back(i);
    }
}

static bool validNumberKey(unsigned char key,int field)
{
    if(field==6 && (key=='.')) return true;
    return isdigit(key) || (key=='-' && field==4);
}

void keyboard(unsigned char key,int,int)
{
    if(key==27){ exit(0); }
    if(key==127) key='\b';

    if(screen==LOGIN || screen==CREATE_ACCOUNT){
        string &target=(loginField==0?userInput:passInput);
        if(key=='\t'){ loginField=1-loginField; }
        else if(key=='\b'){ if(!target.empty()) target.pop_back(); }
        else if(key=='\r'){
            if(screen==CREATE_ACCOUNT){
                if(userInput.empty()||passInput.empty()) setStatus("Enter username and password.");
                else { employerUser=userInput; employerPass=passInput; userInput=passInput=""; loginField=0; employerLogged=true; screen=LOGIN; setStatus("Account created. Login now."); }
            } else {
                if(!employerLogged){
                    if(userInput=="student"&&passInput=="1234"){ userInput=passInput=""; screen=STUDENT_DASH; }
                    else setStatus("Student login is student / 1234.");
                } else {
                    if(userInput==employerUser&&passInput==employerPass){ userInput=passInput=""; screen=EMPLOYER_DASH; }
                    else setStatus("Invalid employer credentials.");
                }
            }
        } else if(key>=32 && key<=126) target += (char)key;
        glutPostRedisplay(); return;
    }

    if(screen==COMPANY_FORM){
        if(key=='\t'||key==13){ if(key=='\r') saveForm(); else nextField(); }
        else if(key=='\b'){ if(!form[activeField].empty()) form[activeField].pop_back(); }
        else if(key>=32&&key<=126){
            if(!numericField(activeField)||validNumberKey(key,activeField)) form[activeField]+=(char)key;
        }
        glutPostRedisplay(); return;
    }

    if(screen==SEARCH){
        if(key=='\b'){ if(!searchText.empty()) searchText.pop_back(); doSearch(); }
        else if(key=='\r') doSearch();
        else if(key>=32&&key<=126){ searchText+=(char)key; doSearch(); }
        else if(key=='b'||key=='B'){ screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH; }
        glutPostRedisplay(); return;
    }

    if(screen==COA){
        string &t=(coaField==0?coaA:coaB);
        if(key=='\t') coaField=1-coaField;
        else if(key=='\b'){ if(!t.empty()) t.pop_back(); }
        else if(key>='0'&&key<='9') t+=(char)key;
        else if(key=='a'||key=='A'){
            try{ coaResult="64-bit addition = "+to_string(processor.addSalary(stoll(coaA),stoll(coaB))); }
            catch(...){ coaResult="Enter valid salary values."; }
        } else if(key=='c'||key=='C'){
            try{ int r=processor.compareSalary(stoll(coaA),stoll(coaB));
                coaResult=(r==1?"Salary A is greater.":r==-1?"Salary B is greater.":"Both salaries are equal."); }
            catch(...){ coaResult="Enter valid salary values."; }
        } else if(key=='b'||key=='B'){ screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH; }
        glutPostRedisplay(); return;
    }

    if(screen==DETAILS){
        if(key=='b'||key=='B') screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
        else if(employerLogged && (key=='e'||key=='E')){
            PLSystem::CompanyView v;
            if(companyData.getAt(selectedCompany,v)){
                form={v.name,v.industry,v.location,v.skills,to_string(v.jobs),to_string(v.salary),
                      to_string(v.rating),to_string(v.skillTransparency),v.review};
                editOriginalName=v.name; activeField=0; editing=true; screen=COMPANY_FORM;
            }
        } else if(employerLogged && (key=='d'||key=='D')){
            PLSystem::CompanyView v;
            if(companyData.getAt(selectedCompany,v)){ companyData.removeGUI(v.name); setStatus("Company deleted."); screen=EMPLOYER_DASH; }
        }
    } else if(screen==COMPANIES){
        if(key=='b'||key=='B') screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
    } else if(screen==ABOUT){
        if(key=='b'||key=='B') screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
    } else if(screen==COMPANY_FORM){
        // handled above
    } else if(screen==STUDENT_DASH){
        if(key=='1') screen=COMPANIES;
        else if(key=='2'){searchText="";searchResults.clear();screen=SEARCH;}
        else if(key=='3') screen=COA;
        else if(key=='4') screen=ABOUT;
        else if(key=='5'){screen=HOME;employerLogged=false;}
    } else if(screen==EMPLOYER_DASH){
        if(key=='1'){resetForm();screen=COMPANY_FORM;}
        else if(key=='2') screen=COMPANIES;
        else if(key=='3'){searchText="";searchResults.clear();screen=SEARCH;}
        else if(key=='4') screen=COA;
        else if(key=='5') screen=ABOUT;
        else if(key=='6'){screen=HOME;employerLogged=false;}
    }
    glutPostRedisplay();
}

void special(int key,int,int)
{
    if(screen==COMPANY_FORM){
        if(key==GLUT_KEY_DOWN||key==GLUT_KEY_RIGHT) nextField();
        else if(key==GLUT_KEY_UP||key==GLUT_KEY_LEFT) activeField=(activeField+8)%9;
        glutPostRedisplay();
    }
}

void mouse(int button,int state,int x,int y)
{
    if(button!=GLUT_LEFT_BUTTON||state!=GLUT_DOWN) return;
    float gx=(float)x/winW*20.0f;
    float gy=10.0f-(float)y/winH*10.0f;

    if(screen==HOME){
        if(hit({2.7f,4.35f,4.55f,5.05f},gx,gy)){employerLogged=false;userInput=passInput="";loginField=0;screen=LOGIN;}
        else if(hit({5.45f,4.35f,7.3f,5.05f},gx,gy)){employerLogged=true;userInput=passInput="";loginField=0;screen=LOGIN;}
        else if(hit({2.7f,3.55f,4.55f,4.15f},gx,gy)){employerLogged=false;userInput=passInput="";loginField=0;screen=CREATE_ACCOUNT;}
        else if(hit({5.45f,3.55f,7.3f,4.15f},gx,gy)) screen=ABOUT;
    } else if(screen==LOGIN){
        if(hit({10.3f,3.55f,18.7f,4.15f},gx,gy)){ keyboard('\r',0,0); }
    } else if(screen==CREATE_ACCOUNT){
        if(hit({10.3f,3.55f,18.7f,4.15f},gx,gy)){ keyboard('\r',0,0); }
    } else if(screen==STUDENT_DASH){
        // Sidebar navigation.
        if(hit({0.35f,7.65f,3.25f,8.23f},gx,gy)) screen=STUDENT_DASH;
        else if(hit({0.35f,6.19f,3.25f,6.77f},gx,gy)) screen=COMPANIES;
        else if(hit({0.35f,5.46f,3.25f,6.04f},gx,gy)){searchText="";searchResults.clear();screen=SEARCH;}
        else if(hit({0.35f,4.73f,3.25f,5.31f},gx,gy)) screen=COA;
        else if(hit({0.35f,4.00f,3.25f,4.58f},gx,gy)) screen=ABOUT;
        else if(hit({4.05f,5.35f,7.60f,6.40f},gx,gy)) screen=COMPANIES;
        else if(hit({7.80f,5.35f,11.35f,6.40f},gx,gy)){searchText="";searchResults.clear();screen=SEARCH;}
        else if(hit({11.55f,5.35f,15.10f,6.40f},gx,gy)) screen=COA;
        else if(hit({15.30f,5.35f,18.85f,6.40f},gx,gy)) screen=ABOUT;
        else if(hit({4.05f,2.90f,11.20f,4.38f},gx,gy)){selectedCompany=0;screen=DETAILS;}
        else if(hit({11.70f,2.90f,18.85f,4.38f},gx,gy)){selectedCompany=1;screen=DETAILS;}
        else if(hit({4.05f,1.22f,11.20f,2.70f},gx,gy)){selectedCompany=2;screen=DETAILS;}
        else if(hit({11.70f,1.22f,18.85f,2.70f},gx,gy)){selectedCompany=3;screen=DETAILS;}
        else if(hit({0.35f,0.20f,3.25f,0.80f},gx,gy)){screen=HOME;employerLogged=false;}
    } else if(screen==EMPLOYER_DASH){
        if(hit({0.35f,7.65f,3.25f,8.23f},gx,gy)) screen=EMPLOYER_DASH;
        else if(hit({0.35f,6.92f,3.25f,7.50f},gx,gy)){resetForm();screen=COMPANY_FORM;}
        else if(hit({0.35f,6.19f,3.25f,6.77f},gx,gy)) screen=COMPANIES;
        else if(hit({0.35f,5.46f,3.25f,6.04f},gx,gy)){searchText="";searchResults.clear();screen=SEARCH;}
        else if(hit({0.35f,4.73f,3.25f,5.31f},gx,gy)) screen=COA;
        else if(hit({0.35f,4.00f,3.25f,4.58f},gx,gy)) screen=ABOUT;
        else if(hit({4.05f,5.35f,7.60f,6.40f},gx,gy)){resetForm();screen=COMPANY_FORM;}
        else if(hit({7.80f,5.35f,11.35f,6.40f},gx,gy)) screen=COMPANIES;
        else if(hit({11.55f,5.35f,15.10f,6.40f},gx,gy)){searchText="";searchResults.clear();screen=SEARCH;}
        else if(hit({15.30f,5.35f,18.85f,6.40f},gx,gy)) screen=COA;
        else if(hit({4.05f,2.90f,11.20f,4.38f},gx,gy)){selectedCompany=0;screen=DETAILS;}
        else if(hit({11.70f,2.90f,18.85f,4.38f},gx,gy)){selectedCompany=1;screen=DETAILS;}
        else if(hit({4.05f,1.22f,11.20f,2.70f},gx,gy)){selectedCompany=2;screen=DETAILS;}
        else if(hit({11.70f,1.22f,18.85f,2.70f},gx,gy)){selectedCompany=3;screen=DETAILS;}
        else if(hit({0.35f,0.20f,3.25f,0.80f},gx,gy)){screen=HOME;employerLogged=false;}
    } else if(screen==COMPANIES){
        if(hit({0.35f,7.65f,3.25f,8.23f},gx,gy)) screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
        else if(hit({0.35f,6.92f,3.25f,7.50f},gx,gy) && employerLogged){resetForm();screen=COMPANY_FORM;}
        else if(hit({0.35f,6.19f,3.25f,6.77f},gx,gy)) screen=COMPANIES;
        else if(hit({0.35f,5.46f,3.25f,6.04f},gx,gy)){searchText="";searchResults.clear();screen=SEARCH;}
        else if(hit({0.35f,4.73f,3.25f,5.31f},gx,gy)) screen=COA;
        else if(hit({0.35f,4.00f,3.25f,4.58f},gx,gy)) screen=ABOUT;
        else {
            int n=min(companyData.countRecords(),8);
            for(int i=0;i<n;i++){
                float col=i%2,row=i/2;
                float x=4.05f+col*7.65f, y=6.65f-row*1.55f;
                if(hit({x,y-1.35f,x+7.15f,y},gx,gy)){selectedCompany=i;screen=DETAILS;break;}
            }
        }
    } else if(screen==SEARCH){
        if(hit({16.5f,6.95f,18.7f,7.65f},gx,gy)) doSearch();
        for(size_t k=0;k<searchResults.size()&&k<6;k++){
            float y=5.75f-k*0.85f;
            if(hit({1,y-0.55f,19,y+0.15f},gx,gy)){selectedCompany=searchResults[k];screen=DETAILS;break;}
        }
    } else if(screen==COMPANY_FORM){
        if(hit({8,1.35f,12,1.95f},gx,gy)) saveForm();
    } else if(screen==DETAILS){
        if(hit({5.2f,2.35f,8.4f,2.95f},gx,gy)) screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
        else if(employerLogged && hit({8.8f,2.35f,12.0f,2.95f},gx,gy)) keyboard('e',0,0);
        else if(employerLogged && hit({12.6f,2.35f,16.0f,2.95f},gx,gy)) keyboard('d',0,0);
    } else if(screen==COA){
        if(hit({2,5.45f,6.9f,6.05f},gx,gy)) keyboard('a',0,0);
        else if(hit({7.9f,5.45f,12.8f,6.05f},gx,gy)) keyboard('c',0,0);
    } else if(screen==ABOUT){
        if(hit({8,1.45f,12,1.95f},gx,gy)) screen=employerLogged?EMPLOYER_DASH:STUDENT_DASH;
    }
    glutPostRedisplay();
}

void reshape(int w,int h)
{
    winW=w;winH=h; glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION); glLoadIdentity(); gluOrtho2D(0,20,0,10);
    glMatrixMode(GL_MODELVIEW); glLoadIdentity();
}

void init()
{
    glClearColor(0.051f,0.090f,0.071f,1.0f);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
}

void runCGL()
{
    // Seed a few records so the visual dashboard is useful immediately.
    if(companyData.countRecords()==0){
        companyData.addGUI("TechNova","Software","Bengaluru","C++, SQL, Git, DSA",18,850000,4.4f,
                           "Good learning environment with clearly described roles.",88);
        companyData.addGUI("GreenGrid","Clean Technology","Pune","Python, IoT, Data Analysis",12,720000,4.1f,
                           "Strong technical exposure; skills are listed clearly.",92);
        companyData.addGUI("FinEdge","FinTech","Mumbai","Java, APIs, Cloud, Testing",25,980000,4.6f,
                           "Structured teams and detailed role expectations.",95);
    }
    int argc=1; char name[]="EcoScope"; char* argv[]={name,nullptr};
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_MULTISAMPLE);
    glutInitWindowSize(1200,760);
    glutCreateWindow("EcoScope - Company Review & Skill Transparency");
    init(); reshape(1200,760);
    glutDisplayFunc(render); glutKeyboardFunc(keyboard); glutSpecialFunc(special);
    glutMouseFunc(mouse); glutReshapeFunc(reshape);
    glutMainLoop();
}
}
