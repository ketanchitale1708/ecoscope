#ifndef OOPS_H
#define OOPS_H
#include <string>

namespace OOPSystem
{
class UserAccount
{
protected:
    std::string username, password;
public:
    virtual ~UserAccount() {}
    virtual std::string role() const = 0;
    void setCredentials(const std::string& u,const std::string& p){username=u;password=p;}
    bool authenticate(const std::string& u,const std::string& p) const { return username==u && password==p; }
};

class StudentAccount : public UserAccount
{
public:
    StudentAccount(){ username="student"; password="1234"; }
    std::string role() const override { return "Student"; }
};

class EmployerAccount : public UserAccount
{
public:
    std::string role() const override { return "Employer"; }
};
}
#endif
