@echo off
setlocal
echo ==========================================
echo EcoScope - Company Review & Skill Transparency
echo ==========================================
echo.
echo Make sure g++ and FreeGLUT are installed and on PATH.
echo.

g++ -std=c++17 -O2 -Wall -Wextra ^
main.cpp CGL\cgl.cpp PL\pl.cpp PSOOP\psoop.cpp OOPS\oops.cpp COA\coa.cpp ^
-I. -lfreeglut -lopengl32 -lglu32 -o EcoScope.exe

if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    echo Check that MinGW and FreeGLUT are installed.
    pause
    exit /b 1
)

echo.
echo BUILD SUCCESSFUL: EcoScope.exe
echo.
EcoScope.exe
