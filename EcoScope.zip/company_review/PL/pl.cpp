#include "pl.h"
#include <iomanip>
#include <limits>

using namespace std;

namespace PLSystem
{

Company::Company()
    : name(""), industry(""), location(""), skills(""),
      jobs(0), salary(0), rating(0.0f), review(""),
      skillTransparency(0)
{
}

void Company::setData(const string& n, const string& ind, const string& loc,
                      const string& sk, int j, long long sal, float r,
                      const string& rev, int transparency)
{
    name = n;
    industry = ind;
    location = loc;
    skills = sk;
    jobs = j;
    salary = sal;
    rating = r;
    review = rev;
    skillTransparency = transparency;
}

void Company::input()
{
    cin >> ws;
    cout << "\nEnter Company Name: "; getline(cin, name);
    cout << "Enter Industry: "; getline(cin, industry);
    cout << "Enter Location: "; getline(cin, location);
    cout << "Enter Required Skills: "; getline(cin, skills);
    cout << "Enter Number of Job Roles: "; cin >> jobs;
    cout << "Enter Average Salary: "; cin >> salary;
    cout << "Enter Rating (0-5): "; cin >> rating;
    cin >> ws;
    cout << "Enter Review: "; getline(cin, review);
    cout << "Skill Transparency (0-100): "; cin >> skillTransparency;
}

void Company::display()
{
    cout << "\nCompany            : " << name
         << "\nIndustry           : " << industry
         << "\nLocation           : " << location
         << "\nRequired Skills    : " << skills
         << "\nJob Roles          : " << jobs
         << "\nAverage Salary     : Rs. " << salary
         << "\nRating             : " << fixed << setprecision(1) << rating << "/5"
         << "\nReview             : " << review
         << "\nSkill Transparency : " << skillTransparency << "%\n";
}

void Company::update()
{
    cin >> ws;
    cout << "\nEnter New Industry: "; getline(cin, industry);
    cout << "Enter New Location: "; getline(cin, location);
    cout << "Enter New Skills: "; getline(cin, skills);
    cout << "Enter New Job Roles: "; cin >> jobs;
    cout << "Enter New Salary: "; cin >> salary;
    cout << "Enter New Rating (0-5): "; cin >> rating;
    cin >> ws;
    cout << "Enter New Review: "; getline(cin, review);
    cout << "New Skill Transparency (0-100): "; cin >> skillTransparency;
}

string Company::getName() const { return name; }

CompanyView Company::view() const
{
    CompanyView v{name, industry, location, skills, jobs, salary,
                  rating, review, skillTransparency};
    return v;
}

CompanyArray::CompanyArray() : count(0) {}

void CompanyArray::insert()
{
    if(count >= 50) { cout << "\nArray is full.\n"; return; }
    companies[count].input();
    ++count;
    cout << "\nCompany added successfully.\n";
}

void CompanyArray::display()
{
    if(count == 0) { cout << "\nNo companies available.\n"; return; }
    for(int i = 0; i < count; ++i) {
        cout << "\nCompany " << i + 1;
        companies[i].display();
    }
}

int CompanyArray::linearSearch(string name) const
{
    for(int i = 0; i < count; ++i)
        if(companies[i].getName() == name) return i;
    return -1;
}

void CompanyArray::search()
{
    if(count == 0) { cout << "\nNo companies available.\n"; return; }
    string name;
    cin >> ws;
    cout << "\nEnter Company Name: "; getline(cin, name);
    int pos = linearSearch(name);
    if(pos < 0) cout << "\nCompany not found.\n";
    else companies[pos].display();
}

void CompanyArray::update()
{
    string name;
    cin >> ws;
    cout << "\nEnter Company Name: "; getline(cin, name);
    int pos = linearSearch(name);
    if(pos < 0) { cout << "\nCompany not found.\n"; return; }
    companies[pos].update();
    cout << "\nCompany updated successfully.\n";
}

void CompanyArray::remove()
{
    string name;
    cin >> ws;
    cout << "\nEnter Company Name: "; getline(cin, name);
    if(!removeGUI(name)) cout << "\nCompany not found.\n";
    else cout << "\nCompany deleted successfully.\n";
}

bool CompanyArray::addGUI(const string& name, const string& industry,
                          const string& location, const string& skills,
                          int jobs, long long salary, float rating,
                          const string& review, int transparency)
{
    if(count >= 50 || name.empty()) return false;
    if(linearSearch(name) >= 0) return false;
    companies[count].setData(name, industry, location, skills, jobs, salary,
                              rating, review, transparency);
    ++count;
    return true;
}

bool CompanyArray::updateGUI(const string& oldName, const string& name,
                             const string& industry, const string& location,
                             const string& skills, int jobs, long long salary,
                             float rating, const string& review, int transparency)
{
    int pos = linearSearch(oldName);
    if(pos < 0 || name.empty()) return false;
    if(name != oldName && linearSearch(name) >= 0) return false;
    companies[pos].setData(name, industry, location, skills, jobs, salary,
                            rating, review, transparency);
    return true;
}

bool CompanyArray::removeGUI(const string& name)
{
    int pos = linearSearch(name);
    if(pos < 0) return false;
    for(int i = pos; i < count - 1; ++i) companies[i] = companies[i + 1];
    --count;
    return true;
}

int CompanyArray::countRecords() const { return count; }

bool CompanyArray::getAt(int index, CompanyView& out) const
{
    if(index < 0 || index >= count) return false;
    out = companies[index].view();
    return true;
}

}
