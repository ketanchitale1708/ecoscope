#ifndef PL_H
#define PL_H

#include <iostream>
#include <string>

using namespace std;

namespace PLSystem
{

struct CompanyView
{
    string name;
    string industry;
    string location;
    string skills;
    int jobs;
    long long salary;
    float rating;
    string review;
    int skillTransparency;
};

class Company
{
private:
    string name;
    string industry;
    string location;
    string skills;
    int jobs;
    long long salary;
    float rating;
    string review;
    int skillTransparency;

public:
    Company();

    void input();
    void display();
    void update();

    void setData(const string& n, const string& ind, const string& loc,
                 const string& sk, int j, long long sal, float r,
                 const string& rev, int transparency);

    string getName() const;
    CompanyView view() const;
};

class CompanyArray
{
private:
    Company companies[50];
    int count;

public:
    CompanyArray();

    void insert();
    void display();
    void search();
    void update();
    void remove();

    int linearSearch(string name) const;

    // GUI-friendly operations
    bool addGUI(const string& name, const string& industry, const string& location,
                const string& skills, int jobs, long long salary, float rating,
                const string& review, int transparency);
    bool updateGUI(const string& oldName, const string& name, const string& industry,
                   const string& location, const string& skills, int jobs,
                   long long salary, float rating, const string& review,
                   int transparency);
    bool removeGUI(const string& name);
    int countRecords() const;
    bool getAt(int index, CompanyView& out) const;
};

}

#endif
