section .text

global add64
global compare64

; 64-bit addition
; RDI = first value
; RSI = second value
; RAX = result

add64:
    mov rax, rdi
    add rax, rsi
    ret


; 64-bit comparison
; RDI = first value
; RSI = second value
; RAX = result
;
; 1  = first > second
; -1 = first < second
; 0  = equal

compare64:
    cmp rdi, rsi
    jg greater
    jl smaller

    mov rax, 0
    ret

greater:
    mov rax, 1
    ret

smaller:
    mov rax, -1
    ret