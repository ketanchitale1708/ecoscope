#ifndef COA_H
#define COA_H

#include <iostream>
using namespace std;

namespace COASystem
{
class Processor
{
private:
    long long R1, R2, R3;
public:
    Processor();
    void loadData(long long a, long long b);
    void add();
    void compare();
    void displayRegisters();
    void runCO1();
    void runCO2();

    // GUI-friendly wrappers
    long long addSalary(long long a, long long b);
    int compareSalary(long long a, long long b);
};

extern "C" long long add64(long long a, long long b);
extern "C" long long compare64(long long a, long long b);
}
#endif
