#include "coa.h"


extern "C" long long add64(long long a, long long b) { return a + b; }
extern "C" long long compare64(long long a, long long b) { return (a>b)?1:(a<b?-1:0); }

namespace COASystem
{
Processor::Processor() : R1(0), R2(0), R3(0) {}

void Processor::loadData(long long a,long long b){ R1=a; R2=b; }
void Processor::add(){ R3=R1+R2; }
void Processor::compare(){ R3=(R1>R2)?1:(R1<R2?-1:0); }

void Processor::displayRegisters()
{
    cout << "\nR1 = " << R1 << "\nR2 = " << R2 << "\nR3 = " << R3 << endl;
}

long long Processor::addSalary(long long a,long long b)
{
    loadData(a,b);
    return add64(a,b);
}

int Processor::compareSalary(long long a,long long b)
{
    loadData(a,b);
    return static_cast<int>(compare64(a,b));
}

void Processor::runCO1()
{
    long long a,b;
    cout << "\n===== COA CO1 =====\n";
    cout << "Enter salary of Company 1: "; cin >> a;
    cout << "Enter salary of Company 2: "; cin >> b;
    loadData(a,b); add(); displayRegisters();
    cout << "Total Salary = " << R3 << endl;
}

void Processor::runCO2()
{
    long long a,b; int choice;
    cout << "\n===== COA CO2 =====\n1. 64-bit Addition\n2. 64-bit Comparison\nEnter choice: ";
    cin >> choice;
    cout << "Enter first salary: "; cin >> a;
    cout << "Enter second salary: "; cin >> b;
    if(choice==1) cout << "64-bit Assembly Addition = " << addSalary(a,b) << endl;
    else if(choice==2) cout << "64-bit Assembly Comparison = " << compareSalary(a,b) << endl;
    else cout << "Invalid choice.\n";
}
}
